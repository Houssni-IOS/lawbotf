import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function ChatPage() {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [llm, setLLM] = useState('ollama');
  const [documents, setDocuments] = useState([]);
  const [chatQuestions, setChatQuestions] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/get_documents')
      .then((response) => response.json())
      .then((data) => setDocuments(data));
  }, []);

  useEffect(() => {
    fetch('/get_chat_questions')
      .then((response) => response.json())
      .then((data) => setChatQuestions(data.questions));
  }, []);

  const handleQuery = async () => {
    const user_id = localStorage.getItem('user_id');
    const conversation_id = localStorage.getItem('conversation_id');

    const response = await fetch('/query', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`
      },
      body: JSON.stringify({ query, llm, user_id, conversation_id }),
    });

    if (response.ok) {
      const data = await response.json();
      setResponse(data.response);
    } else {
      console.error('Error:', response.statusText);
    }
  };

  return (
    <div>
      <h1>Chat Page</h1>
      <select value={llm} onChange={(e) => setLLM(e.target.value)}>
        <option value="ollama">Ollama</option>
        <option value="openai">OpenAI</option>
      </select>
      <textarea
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Enter your query"
      />
      <button onClick={handleQuery}>Submit</button>
      <div>
        <h2>Response</h2>
        <p>{response}</p>
      </div>
    </div>
  );
}

export default ChatPage;
